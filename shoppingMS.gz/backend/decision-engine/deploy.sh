/bin/sh -ec 'mvn clean package -Dmaven.test.skip=true && java -jar target/decsion-engine-0.1.5.jar'
