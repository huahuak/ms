package com.moflowerlkh.decisionengine.service.DepositeActivityDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class DepositActivitySimpleResponseDTO {
    String id;
}
