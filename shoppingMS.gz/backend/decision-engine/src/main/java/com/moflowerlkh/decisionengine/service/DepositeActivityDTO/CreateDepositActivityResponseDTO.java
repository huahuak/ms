package com.moflowerlkh.decisionengine.service.DepositeActivityDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CreateDepositActivityResponseDTO {
    String id;
    String good_id;
}
