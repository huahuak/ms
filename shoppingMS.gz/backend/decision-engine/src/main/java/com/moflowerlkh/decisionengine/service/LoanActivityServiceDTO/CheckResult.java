package com.moflowerlkh.decisionengine.service.LoanActivityServiceDTO;

import lombok.Data;

@Data
public class CheckResult {
    String message;
    Boolean result;
}
