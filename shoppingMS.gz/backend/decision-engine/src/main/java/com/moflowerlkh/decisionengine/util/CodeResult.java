package com.moflowerlkh.decisionengine.util;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class CodeResult {
    String base64String;
    String rendom_string;
}
