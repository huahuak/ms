# ms system
## linux
## run 
```sh
chmod +x bin/start.sh
bin/start.sh
```
## stop
```sh
chmod +x bin/stop.sh
bin/stop.sh
```

## windows

## run 
```bat
bin\start.bat
```
## stop
```bat
bin\stop.bat
```