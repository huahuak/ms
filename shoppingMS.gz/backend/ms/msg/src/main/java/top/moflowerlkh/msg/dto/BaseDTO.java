package top.moflowerlkh.msg.dto;


import lombok.Data;

@Data
public class BaseDTO {
    private String RequestID;
}
