package top.moflowerlkh.msg.common.properties;

public class Consts {
    public static final String RESPONSE_KEY = "RESPONSE_KEY";

    public static final String GOODS_AMOUNT_IN_REDIS_KEY = "GOODS_AMOUNT_IN_REDIS_KEY.GOODS_ID";

    public static final String CHECK_ORDER_KEY = "CHECK_ORDER_KEY";
    public static final String ONE_MAX_AMOUNT_KEY = "ONE_MAX_AMOUNT_KEY";

}
