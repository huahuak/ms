package top.moflowerlkh.backend.disruptor;

public interface ArgEventInterface<A>  {
    void setArg(A a);
}
